enum StartMenuMode {
    case hidden
    case visible(screenID: String)
}
