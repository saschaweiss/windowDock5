//
//  TaskbarStore.swift
//  windowDock5
//
//  Created by Alexander Streb on 06.09.25.
//

