import AppKit
import ApplicationServices
import Foundation

// MARK: - Public Model

public struct WindowInfo: Hashable, Identifiable, Sendable {
    public var id: UUID
    public var bundleID: String
    public var ownerPID: pid_t
    public var windowNumber: Int            // 0 falls unbekannt
    public var title: String
    public var frame: CGRect                // .zero bei unbekannt
    public var isMinimized: Bool
    public var isActive: Bool               // heuristisch/AX
    public var screenID: String?            // displayIDString

    public init(
        id: UUID = UUID(),
        bundleID: String,
        ownerPID: pid_t,
        windowNumber: Int,
        title: String,
        frame: CGRect,
        isMinimized: Bool,
        isActive: Bool,
        screenID: String? = nil
    ) {
        self.id = id
        self.bundleID = bundleID
        self.ownerPID = ownerPID
        self.windowNumber = windowNumber
        self.title = title
        self.frame = frame
        self.isMinimized = isMinimized
        self.isActive = isActive
        self.screenID = screenID
    }
}

// MARK: - Inventory (Actor)

public actor WindowsInventory {
    public static let shared = WindowsInventory()
    
    // —— Caches für minimierte/offscreen Fenster ——
    private var lastScreenByWindowKey: [String: String] = [:]   // "pid:123#wn:45" / "pid:123#t:foo#cx:12#cy:34"
    private var lastScreenByBundle:   [String: String] = [:]    // bid -> screenID
    private var lastWNByPIDTitle:     [String: Int]    = [:]    // "pid:1234#t:chatgpt"
    
    private func cacheKey(pid: pid_t, title: String) -> String {
        "pid:\(pid)#t:\(title.normalizedForKey())"
    }
    private func screenCacheKey(pid: pid_t, wn: Int, title: String, frame: CGRect) -> String {
        if wn != 0 { return "pid:\(pid)#wn:\(wn)" }
        let (cx, cy) = frame.coarseCenterKey()
        return "pid:\(pid)#t:\(title.normalizedForKey())#cx:\(cx)#cy:\(cy)"
    }
    
    // Einfache, gemeinsame Repräsentation für alle Quellen
    private enum WinSource { case cg, ax, sls }
    
    private struct RawWin: Hashable {
        let pid: pid_t
        let bundleID: String
        let wid: UInt32?         // echte WindowID falls bekannt (CG/SLS/AX-WindowNumber)
        let wn: Int              // WindowNumber (0 erlaubt)
        var title: String
        var frame: CGRect        // .zero erlaubt (minimiert)
        var isMinimized: Bool
        var isActive: Bool
        let source: WinSource
    }
    
    // Blacklist für Schein-/Service-„Fenster“
    private let blacklistedBundleIDs: Set<String> = [
        "com.apple.nsattributedstringagent",
        "com.apple.ViewBridgeAuxiliary",
        "com.apple.PubSubAgent",
        "com.apple.coreservices.uiagent",
        "com.apple.loginwindow",
        "com.apple.Spotlight"
    ]
    private let blacklistedNamePrefixes: [String] = [
        "Open and Save Panel Service",
        "CursorUIViewService",
        "UIElement-",
    ]
    
    private func isBlacklisted(app: NSRunningApplication?, title: String) -> Bool {
        if let bid = app?.bundleIdentifier, blacklistedBundleIDs.contains(bid) { return true }
        let t = title.normalizedVisibleTitle().lowercased()
        for p in blacklistedNamePrefixes.map({ $0.lowercased() }) {
            if t.hasPrefix(p) { return true }
        }
        // eigene App raus
        if let my = Bundle.main.bundleIdentifier, app?.bundleIdentifier == my { return true }
        return false
    }
    
    private func screenID(for rect: CGRect) -> String? {
        // Nur mit echten CG-Displays arbeiten (CGWindowBounds sind in globalen CG-Koordinaten)
        guard rect.width > 0, rect.height > 0 else { return nil }
        let maxDisplays: UInt32 = 16
        var displayIDs = [CGDirectDisplayID](repeating: 0, count: Int(maxDisplays))
        var count: UInt32 = 0
        let err = CGGetActiveDisplayList(maxDisplays, &displayIDs, &count)
        if err != .success { return nil }
        
        let center = CGPoint(x: rect.midX, y: rect.midY)
        for i in 0..<Int(count) {
            let did = displayIDs[i]
            let db  = CGDisplayBounds(did) // global CG-Koordinaten
            if db.contains(center) || db.intersects(rect) {
                return String(did) // konsistent mit wd_displayIDString
            }
        }
        return nil
    }
    
    // MARK: Public API
    
    /// Vollsnapshot aller echten App-Fenster (CG > AX > Heuristik) inkl. korrekter screenID.
    /// Screenwahl: (1) SLS Space→Display, (2) größte Schnittfläche mit CGDisplay, (3) Fallbacks/Caches.
    public func snapshot() -> [WindowInfo] {
        // ---------- 0) Vorbereitungen ----------
        // CG sichtbare Fenster (Layer 0, deduped)  → RawWin[]
        let cgRaw = collectCG()

        // Map zur stabilen Zuordnung AX→CG per (pid#wn)
        let cgByPIDWN: [String: CG.CGWin] = Dictionary(uniqueKeysWithValues: cgRaw.compactMap { w in
            guard let wid = w.wid else { return nil }
            return ("\(w.pid)#\(w.wn)", CG.CGWin(ownerPID: Int(w.pid), windowNumber: w.wn, bounds: w.frame, layer: 0, isOnScreen: true, alpha: 1, title: w.title))
        })

        // AX: echte Fenster inkl. minimierter (bereits gefiltert/deduped) → RawWin[]
        let axRaw = collectAX(cgMap: cgByPIDWN)

        // Bekannte WIDs (für SLS-Delta)
        var knownWIDs = Set<UInt32>()
        knownWIDs.formUnion(cgRaw.compactMap { $0.wid })
        knownWIDs.formUnion(axRaw.compactMap { $0.wid })

        // Evidenz je PID (sichtbare CG und AX-minimierte)
        var visibleCGCountByPID: [pid_t: Int] = [:]
        cgRaw.forEach { visibleCGCountByPID[$0.pid] = (visibleCGCountByPID[$0.pid] ?? 0) + 1 }
        let axMinimizedPIDs = Set(axRaw.filter { $0.isMinimized }.map { $0.pid })

        // SLS: sehr konservative Platzhalter (nur wenn Evidenz; per PID gedeckelt)
        let slsRaw = collectSLSPlaceholders(
            knownWIDs: knownWIDs,
            visibleCGCountByPID: visibleCGCountByPID,
            axMinimizedPIDs: axMinimizedPIDs
        )

        // ---------- 1) SkyLight/Spaces-Mapping für Display-Entscheidung ----------
        let (activeSpaces, spaceToDisplay) = buildSpaceMaps()
        let allWIDs = Set(cgRaw.compactMap { $0.wid } + axRaw.compactMap { $0.wid } + slsRaw.compactMap { $0.wid })
        let wid2spaces = SLS.spacesFor(wids: Array(allWIDs))

        // ---------- 2) Harter Merge ohne Doppler ----------
        // Primärschlüssel:
        //   a) wid:WID (wenn vorhanden)
        //   b) pid:PID#wn:WN (wenn WN != 0)
        //   c) pid:PID#t:<normierter Titel> (nur wenn weder WID noch WN)
        @inline(__always)
        func key(for w: RawWin) -> String {
            if let wid = w.wid, wid != 0 { return "wid:\(wid)" }
            if w.wn != 0 { return "pid:\(w.pid)#wn:\(w.wn)" }
            return "pid:\(w.pid)#t:\(w.title.normalizedForKey())"
        }

        // Score: Geometrie vorhanden > aktiv > nicht-minimiert > Quelle (CG>AX>SLS)
        @inline(__always)
        func rank(_ info: WindowInfo, source: WinSource) -> (Int, Int, Int, Int) {
            let hasGeom = info.frame.equalTo(.zero) ? 0 : 1
            let act     = info.isActive ? 1 : 0
            let vis     = info.isMinimized ? 0 : 1
            let src     = (source == .cg ? 3 : (source == .ax ? 2 : 1))
            return (hasGeom, act, vis, src)
        }

        // Vereinheitlichung: wähle finalen Frame/Minimized/Aktiv/Screen in einem Schritt
        var merged: [String: (info: WindowInfo, src: WinSource)] = [:]

        // Hilfsclosure: fügt/ersetzt mit Ranking & Display-Resolution plus Caches
        @inline(__always)
        func commit(_ raw: RawWin) {
            // 2.1 Display robust bestimmen (SLS → Overlap(Thresh) → PID-Heuristik → Caches → Main)
            let scr = resolveDisplay(for: raw,
                                     activeSpaces: activeSpaces,
                                     wid2spaces: wid2spaces,
                                     spaceToDisplay: spaceToDisplay)

            // 2.2 Caches aktualisieren (nur wenn wir ein Ziel haben)
            if let s = scr {
                let k = screenCacheKey(pid: raw.pid, wn: raw.wn, title: raw.title, frame: raw.frame)
                lastScreenByWindowKey[k] = s
                if raw.wn != 0 { lastScreenByWindowKey["pid:\(raw.pid)#wn:\(raw.wn)"] = s }
                lastScreenByBundle[raw.bundleID] = s
            }

            let info = WindowInfo(
                bundleID: raw.bundleID,
                ownerPID: raw.pid,
                windowNumber: raw.wn,
                title: raw.title,
                frame: raw.frame,
                isMinimized: raw.isMinimized,
                isActive: raw.isActive,
                screenID: scr
            )

            let k = key(for: raw)
            if let cur = merged[k] {
                // Wähle „besseres“ nach (Geom > Aktiv > Nicht-min > Quellrang)
                if rank(info, source: raw.source) > rank(cur.info, source: cur.src) {
                    merged[k] = (info, raw.source)
                }
            } else {
                merged[k] = (info, raw.source)
            }
        }

        // Commit-Reihenfolge: CG → AX → SLS (damit CG-Geometrie bevorzugt wird, AX-Status sichtbar bleibt, SLS nur Lücken füllt)
        cgRaw.forEach(commit)
        axRaw.forEach(commit)
        slsRaw.forEach(commit)

        // ---------- 3) Kein Geometrie-Merging mehr nötig ----------
        // WN/WID verhindern bereits Doppler. Nur sehr seltene Fälle ohne WID/ohne WN kommen durch;
        // die haben aber *keine* Minimized-Zusammenlegung (jede Minimierte bleibt einzeln).
        // Wir geben einfach die Werte zurück.
        return merged.values.map { $0.info }
    }
    
    /// Wählt das Display mit der größten Schnittfläche zum Fenster-Rect.
    /// Verhindert „ein paar Pixel rüberlugen“ → falscher Bildschirm.
    private func displayIDByMaxIntersection(for rect: CGRect) -> String? {
        guard rect.width > 0, rect.height > 0 else { return nil }
        let maxDisplays: UInt32 = 16
        var displayIDs = [CGDirectDisplayID](repeating: 0, count: Int(maxDisplays))
        var count: UInt32 = 0
        guard CGGetActiveDisplayList(maxDisplays, &displayIDs, &count) == .success else { return nil }
        
        var bestArea: CGFloat = 0
        var best: CGDirectDisplayID?
        for i in 0..<Int(count) {
            let did = displayIDs[i]
            let db = CGDisplayBounds(did)
            let inter = db.intersection(rect)
            let area = max(0, inter.width * inter.height)
            if area > bestArea { bestArea = area; best = did }
        }
        if let b = best, bestArea > 0 { return String(b) }
        
        // Fallback: Center enthält
        let c = CGPoint(x: rect.midX, y: rect.midY)
        for i in 0..<Int(count) {
            let did = displayIDs[i]
            if CGDisplayBounds(did).contains(c) { return String(did) }
        }
        return nil
    }
    
    /// Mappt Space-ID → CGDirectDisplayID über SkyLight „ManagedDisplaySpaces“ und CGDisplayUUIDs.
    private func buildSpaceToDisplayMap() -> [UInt64: CGDirectDisplayID] {
        var map: [UInt64: CGDirectDisplayID] = [:]
        
        // Baue DisplayUUID(String) → CGDirectDisplayID
        let maxDisplays: UInt32 = 16
        var displayIDs = [CGDirectDisplayID](repeating: 0, count: Int(maxDisplays))
        var count: UInt32 = 0
        guard CGGetActiveDisplayList(maxDisplays, &displayIDs, &count) == .success else { return map }
        
        var uuidToDisplay: [String: CGDirectDisplayID] = [:]
        for i in 0..<Int(count) {
            let did = displayIDs[i]
            if let uuid = CGDisplayCreateUUIDFromDisplayID(did)?.takeRetainedValue(),
               let s = CFUUIDCreateString(nil, uuid) as String? {
                uuidToDisplay[s] = did
            }
        }
        
        for ds in SLS.managedDisplaySpaces() {
            if let did = uuidToDisplay[ds.displayUUID] {
                for sid in ds.spaceIDs { map[sid] = did }
            }
        }
        return map
    }
    
    // —— helpers ——
    private func runtimeKey(pid: pid_t, wn: Int, bundleID: String, title: String, frame: CGRect) -> String {
        if wn != 0 { return "pid:\(pid)#wn:\(wn)" }
        let (cx, cy) = frame.coarseCenterKey()
        return "pid:\(pid)#t:\(title.normalizedForKey())#cx:\(cx)#cy:\(cy)#bid:\(bundleID)"
    }
    
    /// Wählt das Display für ein Fenster:
    /// 1) WID -> Spaces (nur aktive) -> Display  (mitgegeben als Maps)
    /// 2) Wenn `rect` bekannt: größter Flächen-Overlap
    /// 3) Fallback: erster Kandidat oder Main
    private func preferredDisplayID(wid: UInt32?, rect: CGRect?, activeSpaces: Set<UInt64>, wid2spaces: [UInt32: [UInt64]], spaceToDisplay: [UInt64: CGDirectDisplayID]) -> String? {
        // Kandidaten aus (WID -> aktive Spaces -> Display)
        var candidates = [CGDirectDisplayID]()
        if let wid = wid, let sids = wid2spaces[wid] {
            for sid in sids where activeSpaces.contains(sid) {
                if let did = spaceToDisplay[sid] {
                    candidates.append(did)
                }
            }
        }
        
        // Wenn Geometrie vorhanden → „bestes“ Display anhand maximaler Schnittfläche
        if let r = rect, r.width > 0, r.height > 0 {
            // Kandidaten aus SLS bevorzugen – wenn leer, nimm alle aktiven Displays
            let dids: [CGDirectDisplayID] = {
                if !candidates.isEmpty { return candidates }
                var buf = [CGDirectDisplayID](repeating: 0, count: 16)
                var count: UInt32 = 0
                return (CGGetActiveDisplayList(UInt32(buf.count), &buf, &count) == .success)
                ? Array(buf.prefix(Int(count)))
                : []
            }()
            
            var best: (did: CGDirectDisplayID, area: CGFloat)? = nil
            for did in dids {
                let area = CGDisplayBounds(did).intersection(r).area
                if area > (best?.area ?? 0) { best = (did, area) }
            }
            if let b = best, b.area > 0 { return String(b.did) }
            
            // fallback: Center enthält
            let c = CGPoint(x: r.midX, y: r.midY)
            for did in dids where CGDisplayBounds(did).contains(c) { return String(did) }
        }
        
        // Kein/kaum Rect: nimm ersten SLS-Kandidaten, wenn vorhanden
        if let did = candidates.first { return String(did) }
        
        // Letzter Fallback
        return NSScreen.main?.wd_displayIDString
    }
    
    /// Robust: ermittelt eine screenID mit mehrfachen Fallbacks.
    /// Reihenfolge:
    /// 1) SLS (aktive Spaces dieses WID → Display)
    /// 2) Overlap mit Schwellwert (>= 0.25 der Fensterfläche) auf SLS-Kandidaten, sonst alle Displays
    /// 3) PID-Heuristik (irgendein sichtbares CG-Fenster derselben PID → Overlap)
    /// 4) Caches (WindowKey, WN, Bundle)
    /// 5) Main
    private func resolveDisplay(for w: RawWin, activeSpaces: Set<UInt64>, wid2spaces: [UInt32: [UInt64]], spaceToDisplay: [UInt64: CGDirectDisplayID]) -> String? {
        // 1) SLS-Kandidaten
        var slsCandidates = [CGDirectDisplayID]()
        if let wid = w.wid, let sids = wid2spaces[wid] {
            for sid in sids where activeSpaces.contains(sid) {
                if let did = spaceToDisplay[sid] {
                    slsCandidates.append(did)
                }
            }
        }

        // 2) Overlap mit Threshold
        if w.frame.width > 0, w.frame.height > 0 {
            if let did = bestDisplayByOverlap(for: w.frame, preferred: slsCandidates, minFraction: 0.25) {
                return String(did)
            }
        }

        // 3) PID-Heuristik: nimm *irgendein* sichtbares CG-Fenster derselben PID und bewerte Overlap
        if let any = CG.anyOnscreenWindowBounds(for: w.pid), any.width > 0, any.height > 0 {
            if let did = bestDisplayByOverlap(for: any, preferred: slsCandidates, minFraction: 0.10) {
                return String(did)
            }
        }

        // 4) Caches
        let k = screenCacheKey(pid: w.pid, wn: w.wn, title: w.title, frame: w.frame)
        if let s = lastScreenByWindowKey[k] ?? lastScreenByWindowKey["pid:\(w.pid)#wn:\(w.wn)"] {
            return s
        }
        if let s = lastScreenByBundle[w.bundleID] { return s }

        // 5) Fallback: Main
        return NSScreen.main?.wd_displayIDString
    }
    
    /// Nimmt eine Geometrie und sucht das Display mit größter Schnittfläche.
    /// Wenn `preferred` leer → alle aktiven Displays.
    /// `minFraction`: Mindestanteil (Fläche(intersect)/Fläche(rect)), damit „ein paar Pixel rüberlugen“ nicht falschen Bildschirm triggert.
    private func bestDisplayByOverlap(for rect: CGRect, preferred: [CGDirectDisplayID], minFraction: CGFloat) -> CGDirectDisplayID? {
        let dids: [CGDirectDisplayID] = {
            if !preferred.isEmpty { return preferred }
            var buf = [CGDirectDisplayID](repeating: 0, count: 16)
            var count: UInt32 = 0
            guard CGGetActiveDisplayList(UInt32(buf.count), &buf, &count) == .success else { return [] }
            return Array(buf.prefix(Int(count)))
        }()

        let areaRect = max(0, rect.width * rect.height)
        var best: (CGDirectDisplayID, CGFloat) = (0, 0)

        for did in dids {
            let inter = CGDisplayBounds(did).intersection(rect)
            let a = max(0, inter.width * inter.height)
            if a > best.1 { best = (did, a) }
        }

        if areaRect > 0, best.1 / areaRect >= minFraction, best.0 != 0 {
            return best.0
        }

        // Fallback: Center enthält (nur wenn kein sinnvoller Overlap gefunden)
        let c = CGPoint(x: rect.midX, y: rect.midY)
        for did in dids where CGDisplayBounds(did).contains(c) {
            return did
        }
        return nil
    }
    
    // CG-Sammler: nur Layer-0, sichtbar, sinnvoll groß, ohne Hilfsfenster
    private func collectCG() -> [RawWin] {
        let cgPrimary = CG.collect(options: [.optionOnScreenOnly, .excludeDesktopElements])
        let cgAll     = CG.collect(options: [.optionAll, .excludeDesktopElements])

        var cgByKey: [String: CG.CGWin] = [:] // "pid#wn"
        for w in (cgPrimary + cgAll) {
            if w.layer != 0 { continue }
            if !w.isOnScreen || w.alpha <= 0.01 { continue }
            if w.bounds.width < 48 || w.bounds.height < 32 { continue }
            if let app = NSRunningApplication(processIdentifier: w.ownerPID_t),
               isBlacklisted(app: app, title: w.title ?? "") { continue }

            let k = "\(w.ownerPID)#\(w.windowNumber)"
            if let old = cgByKey[k] {
                if old.bounds.equalTo(.zero) && !w.bounds.equalTo(.zero) { cgByKey[k] = w }
            } else {
                cgByKey[k] = w
            }
        }

        // leichte Geometrie-Dedupe (gegen identische Doppler)
        if !cgByKey.isEmpty {
            var bestByGeom: [String: CG.CGWin] = [:]
            func score(_ x: CG.CGWin) -> (Int, CGFloat) { (x.isOnScreen ? 1 : 0, x.bounds.width * x.bounds.height) }
            for w in cgByKey.values {
                let (cx, cy) = w.bounds.coarseCenterKey(grid: 8)
                let key = "\(w.ownerPID)#\(cx)#\(cy)#\(Int(w.bounds.width))#\(Int(w.bounds.height))"
                if let cur = bestByGeom[key] {
                    if score(w) > score(cur) { bestByGeom[key] = w }
                } else {
                    bestByGeom[key] = w
                }
            }
            cgByKey = Dictionary(uniqueKeysWithValues: bestByGeom.map { ("\($0.value.ownerPID)#\($0.value.windowNumber)", $0.value) })
        }

        return cgByKey.values.compactMap { cg in
            guard let app = NSRunningApplication(processIdentifier: cg.ownerPID_t),
                  let bid = app.bundleIdentifier else { return nil }
            let title = (cg.title ?? "").normalizedVisibleTitle().isEmpty ? (app.localizedName ?? "") : (cg.title ?? "")
            return RawWin(pid: cg.ownerPID_t,
                          bundleID: bid,
                          wid: UInt32(cg.windowNumber),
                          wn: cg.windowNumber,
                          title: title,
                          frame: cg.bounds,
                          isMinimized: false,
                          isActive: NSWorkspace.shared.frontmostApplication?.processIdentifier == app.processIdentifier,
                          source: .cg)
        }
    }

    // AX-Sammler: echte Fenster inkl. minimierter; nicht-minimierte nur, wenn plausibel
    private func collectAX(cgMap: [String: CG.CGWin]) -> [RawWin] {
        let ax = AX.snapshotAllDeduped()
        return ax.compactMap { a in
            guard let bid = a.bundleID else { return nil }
            let app = NSRunningApplication(processIdentifier: a.ownerPID)
            if isBlacklisted(app: app, title: a.title) { return nil }

            var rect = a.frame
            let cgKey = "\(a.ownerPID)#\(a.windowNumber)"
            let hasCG = (a.windowNumber != 0) && (cgMap[cgKey] != nil)

            // Nicht-minimiert ohne CG → nur Standardfenster nehmen
            if !a.isMinimized && !hasCG && !AX.isStandardMainWindow(role: a.role, subrole: a.subrole) {
                return nil
            }

            if rect.equalTo(.zero), let cg = cgMap[cgKey] { rect = cg.bounds }

            var title = a.title.normalizedVisibleTitle()
            if title.isEmpty, let appName = app?.localizedName { title = appName }

            return RawWin(pid: a.ownerPID,
                          bundleID: bid,
                          wid: a.windowNumber > 0 ? UInt32(a.windowNumber) : nil,
                          wn: a.windowNumber,
                          title: title,
                          frame: rect,
                          isMinimized: a.isMinimized,
                          isActive: a.isActive,
                          source: .ax)
        }
    }

    // SLS-Placeholders: sehr konservativ; nur wenn PID Evidenz hat (sichtbar ODER AX-minimiert)
    private func collectSLSPlaceholders(knownWIDs: Set<UInt32>, visibleCGCountByPID: [pid_t:Int], axMinimizedPIDs: Set<pid_t>) -> [RawWin] {
        let allWIDs  = Set(SLS.allWindows())
        let missing  = allWIDs.subtracting(knownWIDs)
        if missing.isEmpty { return [] }

        let missMap  = SLS.spacesFor(wids: Array(missing))
        let active   = SLS.activeSpaces()

        var out: [RawWin] = []
        var budget: [pid_t:Int] = [:]

        func cap(for pid: pid_t) -> Int {
            let hasVisible = (visibleCGCountByPID[pid] ?? 0) > 0
            let hasAXMin   = axMinimizedPIDs.contains(pid)
            if !hasVisible && !hasAXMin { return 0 }
            return hasVisible ? 3 : 1
        }

        // stabile Reihenfolge
        for wid in missing.sorted() {
            if let sids = missMap[wid], !sids.isEmpty, !sids.contains(where: { active.contains($0) }) { continue }

            guard let pid = CG.pid(forWindowID: wid) ?? CG.widToPIDMap()[wid],
                  let app = NSRunningApplication(processIdentifier: pid),
                  app.activationPolicy == .regular,
                  let bid = app.bundleIdentifier,
                  !blacklistedBundleIDs.contains(bid) else { continue }

            let c = cap(for: pid)
            if c == 0 { continue }
            let used = budget[pid] ?? 0
            if used >= c { continue }
            budget[pid] = used + 1

            out.append(RawWin(pid: pid,
                              bundleID: bid,
                              wid: wid,
                              wn: Int(wid),
                              title: app.localizedName ?? "",
                              frame: .zero,
                              isMinimized: true,
                              isActive: false,
                              source: .sls))
        }

        return out
    }
    
    // baut die Maps für Space→Display
    private func buildSpaceMaps() -> (active: Set<UInt64>, map: [UInt64: CGDirectDisplayID]) {
        let active = SLS.activeSpaces()
        return (active, buildSpaceToDisplayMap())
    }

    // Display bestimmen (SLS → Overlap → Fallback/Caches)
    private func pickDisplay(for w: RawWin, activeSpaces: Set<UInt64>, wid2spaces: [UInt32: [UInt64]], spaceToDisplay: [UInt64: CGDirectDisplayID]) -> String? {
        // 1) SLS: aktive Spaces des WID
        if let wid = w.wid, let sids = wid2spaces[wid] {
            for sid in sids where activeSpaces.contains(sid) {
                if let did = spaceToDisplay[sid] { return String(did) }
            }
        }

        // 2) Overlap mit echten Displays falls Frame bekannt
        if w.frame.width > 0, w.frame.height > 0, let s = displayIDByMaxIntersection(for: w.frame) {
            return s
        }

        // 3) Cache-Fallbacks
        let key = screenCacheKey(pid: w.pid, wn: w.wn, title: w.title, frame: w.frame)
        if let s = lastScreenByWindowKey[key] ?? lastScreenByWindowKey["pid:\(w.pid)#wn:\(w.wn)"] { return s }
        if let s = lastScreenByBundle[w.bundleID] { return s }

        return NSScreen.main?.wd_displayIDString
    }
}

private extension CGRect { var area: CGFloat { max(0, width * height) } }

// MARK: - CG helper
fileprivate enum CG {
    struct CGWin {
        let ownerPID: Int
        var ownerPID_t: pid_t { pid_t(ownerPID) }
        let windowNumber: Int
        let bounds: CGRect
        let layer: Int
        let isOnScreen: Bool
        let alpha: CGFloat
        let title: String?
    }

    static func collect(options: CGWindowListOption) -> [CGWin] {
        guard let listInfo = CGWindowListCopyWindowInfo(options, kCGNullWindowID) as? [[String: Any]] else { return [] }
        var out: [CGWin] = []
        for dict in listInfo {
            let layer   = dict[kCGWindowLayer as String] as? Int ?? 0
            if layer != 0 { continue } // nur „normale“ App-Fenster

            let ownerPID = dict[kCGWindowOwnerPID as String] as? Int ?? 0
            let wn       = dict[kCGWindowNumber   as String] as? Int ?? 0
            let isOnScr  = (dict[kCGWindowIsOnscreen as String] as? Bool) ?? false
            let alpha    = (dict[kCGWindowAlpha as String] as? CGFloat) ?? 1.0

            // ganz schwach sichtbare oder explizit offscreen -> aussortieren
            if alpha <= 0.01 || isOnScr == false { continue }

            var bounds = CGRect.zero
            if let b = dict[kCGWindowBounds as String] as? [String: Any] {
                bounds = CGRect(
                    x: (b["X"] as? CGFloat) ?? 0,
                    y: (b["Y"] as? CGFloat) ?? 0,
                    width: (b["Width"] as? CGFloat) ?? 0,
                    height: (b["Height"] as? CGFloat) ?? 0
                )
            }
            let title = dict[kCGWindowName as String] as? String

            out.append(CGWin(ownerPID: ownerPID, windowNumber: wn, bounds: bounds, layer: layer, isOnScreen: isOnScr, alpha: alpha, title: title))
        }
        return out
    }
    
    /// Sucht *irgendein* sichtbares CG-Fenster derselben PID (egal welcher Layer),
    /// um den Display zu bestimmen (nur für Screen-Heuristik; AppStore-safe).
    static func anyOnscreenWindowBounds(for pid: pid_t) -> CGRect? {
        guard let listInfo = CGWindowListCopyWindowInfo([.optionAll, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        var best: (CGRect, CGFloat) = (.zero, 0) // (bounds, area)

        for dict in listInfo {
            let owner = dict[kCGWindowOwnerPID as String] as? Int ?? 0
            if owner != Int(pid) { continue }

            let isOnScr  = (dict[kCGWindowIsOnscreen as String] as? Bool) ?? false
            let alpha    = (dict[kCGWindowAlpha as String] as? CGFloat) ?? 1.0
            guard isOnScr, alpha > 0.01 else { continue }

            if let b = dict[kCGWindowBounds as String] as? [String: Any] {
                let r = CGRect(x: (b["X"] as? CGFloat) ?? 0,
                               y: (b["Y"] as? CGFloat) ?? 0,
                               width: (b["Width"] as? CGFloat) ?? 0,
                               height: (b["Height"] as? CGFloat) ?? 0)
                let area = max(0, r.width * r.height)
                if area > best.1 { best = (r, area) }
            }
        }
        return best.1 > 0 ? best.0 : nil
    }

    static func guessNumber(ownerPID: Int, approxFrame: CGRect?, approxTitle: String?) -> Int? {
        let all = collect(options: [.optionAll, .excludeDesktopElements]).filter { $0.ownerPID == ownerPID }
        if let f = approxFrame, !f.isEmpty {
            return all.min(by: { $0.bounds.center.distance(to: f.center) < $1.bounds.center.distance(to: f.center) })?.windowNumber
        }
        if let t = approxTitle, !t.isEmpty {
            return all.first(where: { ($0.title ?? "").hasPrefix(t) })?.windowNumber
        }
        return all.first?.windowNumber
    }
    
    // Map every CG WindowID -> owner PID (safe for minimized/off-screen)
    static func widToPIDMap() -> [UInt32: pid_t] {
        guard let info = CGWindowListCopyWindowInfo([.optionAll, .excludeDesktopElements],
                                                    kCGNullWindowID) as? [[String: Any]] else { return [:] }
        var out: [UInt32: pid_t] = [:]
        out.reserveCapacity(info.count)
        for d in info {
            let wid: UInt32
            if let n = d[kCGWindowNumber as String] as? NSNumber {
                wid = n.uint32Value
            } else if let n = d[kCGWindowNumber as String] as? Int {
                wid = UInt32(n)
            } else { continue }

            if let pidInt = d[kCGWindowOwnerPID as String] as? Int {
                out[wid] = pid_t(pidInt)
            }
        }
        return out
    }
    
    // Map one CG WindowID -> owner PID (safe even for minimized/off-screen)
    static func pid(forWindowID wid: UInt32) -> pid_t? {
        guard let info = CGWindowListCopyWindowInfo([.optionAll, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        for d in info {
            let num: UInt32
            if let n = d[kCGWindowNumber as String] as? NSNumber { num = n.uint32Value }
            else if let n = d[kCGWindowNumber as String] as? Int { num = UInt32(n) }
            else { continue }
            if num == wid, let pidInt = d[kCGWindowOwnerPID as String] as? Int {
                return pid_t(pidInt)
            }
        }
        return nil
    }
}

// MARK: - AX helper
fileprivate enum AX {
    struct AXWin: Hashable {
        let ownerPID: pid_t
        let bundleID: String?
        let title: String
        let role: String?
        let subrole: String?
        let isMinimized: Bool
        let isActive: Bool
        let frame: CGRect
        let windowNumber: Int
    }
    
    // Nur Standard-Hauptfenster erlauben (WindowRole + StandardWindowSubrole)
    static func isStandardMainWindow(role: String?, subrole: String?) -> Bool {
        guard role == (kAXWindowRole as String) else { return false }
        // Nur Standardfenster zulassen
        if let sr = subrole { return sr == (kAXStandardWindowSubrole as String) }
        // Fehlt die Subrole, konservativ ablehnen
        return false
    }

    /// Liefert deduplizierte & gefilterte AX-Fenster.
    static func snapshotAllDeduped() -> [AXWin] {
        if !AXIsProcessTrustedWithOptions(nil) {
            print("AX not trusted – enable in System Settings > Privacy & Security > Accessibility")
        }
        guard AXIsProcessTrustedWithOptions(nil) else { return [] }

        var out: [AXWin] = []
        var seenWN: Set<String> = []     // "pid:123#wn:45"
        var seenLoose: Set<String> = []  // "pid:123#t:foo#cx:12#cy:34#sr:Standard"

        let running = NSWorkspace.shared.runningApplications.filter {
            $0.activationPolicy == .regular && $0.bundleIdentifier != Bundle.main.bundleIdentifier
        }
        let frontPID = NSWorkspace.shared.frontmostApplication?.processIdentifier

        for app in running {
            let pid   = app.processIdentifier
            let appEl = AXUIElementCreateApplication(pid)

            // Nur die vollständige Fensterliste nutzen (kein Focus/Main vorweg)
            // neu: mehrere Wege probieren
            let wins: [AnyObject] = (
                copyArray(appEl, kAXWindowsAttribute as CFString) ??
                copyArray(appEl, "AXAllWindows" as CFString) ??               // inoffiziell, aber oft vorhanden
                copyArray(appEl, kAXChildrenAttribute as CFString) ?? []       // manche Apps hängen Fenster unter children
            )
            if wins.isEmpty { continue }

            for case let el as AXUIElement in wins {
                guard var w = makeAXWin(el, ownerPID: pid, app: app, isFrontApp: (pid == frontPID)) else { continue }
                
                if let hidden = copyValue(el, kAXHiddenAttribute as CFString) as? Bool, hidden == true {
                    continue
                }

                // Minimierte behalten, solange es AXWindowRole ist (Subrole egal)
                if w.isMinimized {
                    guard w.role == (kAXWindowRole as String) else { continue }
                } else {
                    // Nicht-minimiert: nur offensichtliche Hilfsfenster raus
                    if AX.isAuxiliaryLike(role: w.role, subrole: w.subrole) { continue }
                    // Sehr kleine Phantomfenster raus
                    if w.frame.width < 16 || w.frame.height < 16 { continue }
                }

                // Leere Titel zulassen, WENN minimiert (Dock-Items haben oft keinen Titel)
                let normTitle = w.title.normalizedVisibleTitle()
                if !w.isMinimized && normTitle.isEmpty {
                    // bei fehlendem Titel: auf App-Namen fallen (dann haben wir immerhin 1 Button)
                    if let appName = NSRunningApplication(processIdentifier: w.ownerPID)?.localizedName, !appName.isEmpty {
                        w = AXWin(ownerPID: w.ownerPID, bundleID: w.bundleID, title: appName,
                                  role: w.role, subrole: w.subrole, isMinimized: w.isMinimized,
                                  isActive: w.isActive, frame: w.frame, windowNumber: w.windowNumber)
                    } else {
                        continue
                    }
                } else if normTitle != w.title {
                    // Normalisierten Titel übernehmen
                    w = AXWin(ownerPID: w.ownerPID, bundleID: w.bundleID, title: normTitle,
                              role: w.role, subrole: w.subrole, isMinimized: w.isMinimized,
                              isActive: w.isActive, frame: w.frame, windowNumber: w.windowNumber)
                }

                // Titel normalisieren; „Untitled“ & Co. vereinheitlichen
                w = AXWin(ownerPID: w.ownerPID,
                          bundleID: w.bundleID,
                          title: normTitle, // <— normalisiert
                          role: w.role,
                          subrole: w.subrole,
                          isMinimized: w.isMinimized,
                          isActive: w.isActive,
                          frame: w.frame,
                          windowNumber: w.windowNumber)

                if w.windowNumber != 0 {
                    let k = "pid:\(w.ownerPID)#wn:\(w.windowNumber)"
                    if seenWN.contains(k) { continue }
                    seenWN.insert(k)
                } else {
                    let (cx, cy) = w.frame.coarseCenterKey()
                    let sr = (w.subrole ?? "nil")
                    let k = "pid:\(w.ownerPID)#t:\(w.title.normalizedForKey())#cx:\(cx)#cy:\(cy)#sr:\(sr)"
                    if seenLoose.contains(k) { continue }
                    seenLoose.insert(k)
                }

                out.append(w)
            }
        }
        return out
    }

    /// Nur echte Hauptfenster zulassen; Hilfsfenster raus
    static func isAuxiliaryLike(role: String?, subrole: String?) -> Bool {
        // nur AXWindowRole zulassen
        guard role == (kAXWindowRole as String) else { return true }

        // Standardfenster explizit behalten
        if subrole == (kAXStandardWindowSubrole as String) { return false }

        // Häufige Nicht-Hauptfenster raus (Konstanten ODER Fallback-Literals)
        let s = subrole
        if s == (kAXDialogSubrole as String)           || s == "AXDialog"        { return true }
        if s == (kAXSystemDialogSubrole as String)     || s == "AXSystemDialog"  { return true }
        if s == (kAXFloatingWindowSubrole as String)   || s == "AXFloatingWindow"{ return true }
        if s == (kAXUnknownSubrole as String)          || s == "AXUnknown"       { return true }
        if                     /* evtl. nicht im SDK */    s == "AXSheet"        { return true }
        if                                                     s == "AXGrowArea"     { return true }
        if                                                     s == "AXUtilityWindow"{ return true }
        if                                                     s == "AXHUDWindow"    { return true }

        // Wenn keine (erkennbare) Subrole → als potentiell Hauptfenster durchlassen
        return false
    }

    private static func makeAXWin(_ el: AXUIElement, ownerPID: pid_t, app: NSRunningApplication, isFrontApp: Bool) -> AXWin? {
        let role    = copyValue(el, kAXRoleAttribute as CFString)    as? String
        let subrole = copyValue(el, kAXSubroleAttribute as CFString) as? String
        if role != (kAXWindowRole as String) { return nil }

        let isMin = (copyValue(el, kAXMinimizedAttribute as CFString) as? Bool) ?? false
        let title = (copyValue(el, kAXTitleAttribute     as CFString) as? String) ?? ""

        var frame = CGRect.zero
        if let pos  = copyValue(el, kAXPositionAttribute as CFString) as? CGPoint,
           let size = copyValue(el, kAXSizeAttribute     as CFString) as? CGSize {
            frame = CGRect(origin: pos, size: size)
        }

        var wn: Int = 0
        if let n = copyValue(el, "_AXWindowID"      as CFString) as? Int { wn = n }
        else if let n = copyValue(el, "AXWindowNumber" as CFString) as? Int { wn = n }

        return AXWin(ownerPID: ownerPID,
                     bundleID: app.bundleIdentifier,
                     title: title,
                     role: role,
                     subrole: subrole,
                     isMinimized: isMin,
                     isActive: isFrontApp && !isMin,
                     frame: frame,
                     windowNumber: wn)
    }

    // CFString helpers
    private static func copyArray(_ root: AXUIElement, _ attr: CFString) -> [AnyObject]? {
        var v: CFTypeRef?
        let err = AXUIElementCopyAttributeValue(root, attr, &v)
        if err == .success, let arr = v { return (arr as! [AnyObject]) }
        return nil
    }
    private static func copyValue(_ el: AXUIElement, _ attr: CFString) -> AnyObject? {
        var v: CFTypeRef?
        let err = AXUIElementCopyAttributeValue(el, attr, &v)
        if err == .success, let out = v { return (out as AnyObject) }
        return nil
    }
}
